<template>
  <div class="container">
    <div class="left">
      <header>
        <h1>TodoList add</h1>
      </header>

      <div class="add-todo">
        <input type="text" placeholder="Todo" id="zonetodo" v-model="newTodo">
        <button @click="addTodo">Add</button>
        <button @click="resetAll">Reset</button>
      </div>

    </div>


    <div class="right">

        <div class="list">
          <ul>
            <li v-for="(todo , index) in listTodo" :key="todo">{{ todo }}
            <button @click="deleteTodo(index)" id="delete">Delete</button>
            </li>
          </ul>
        </div>
    </div>


  </div>
</template>
<script>
export default {
  data(){
    return {

      newTodo : ' ',
      listTodo : [],
    }
  },
  methods : {
    addTodo(){
      if (this.newTodo !==''){
        this.listTodo.push(this.newTodo)
        this.newTodo = ''
      }

    },
    resetAll(){
      this.listTodo = []
    },
    deleteTodo(index){
      this.listTodo.splice(index , 1)
    }
  }
}
</script>
